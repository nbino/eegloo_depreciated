class ListingsController < ApplicationController
  # GET /listings
  # GET /listings.xml
  def index
    @listings = Listing.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @listings }
    end
  end

  # GET /listings/1
  # GET /listings/1.xml
  def show
    @listing = Listing.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @listing }
    end
  end

  # GET /listings/new
  # GET /listings/new.xml
  def new
    @listing = Listing.new
    
    @room1 = Room.new
    @room2 = Room.new
    @room3 = Room.new
    @room4 = Room.new
    @living_room = Room.new
    
    @apt_types = AptType.find(:all)
    @rent_ranges = RentRange.find(:all)
    @floor_types = FloorType.find(:all)
    @ac_types = ACType.find(:all)
    @quality_choices = Quality.find(:all)
    @light_levels = LightLevel.find(:all)
    @noise_levels = Direction.find(:all)
    @directions = Direction.find(:all)
    
#    @yes_no = YesNo.find(:all)
    

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @listing }
    end
  end

  # GET /listings/1/edit
  def edit
    @listing = Listing.find(params[:id])
  end

  # POST /listings
  # POST /listings.xml
  def create
    @listing = Listing.new(params[:listing])
    @room1 = Room.new(params[:room1])
    @room2 = Room.new(params[:room2])
    @room3 = Room.new(params[:room3])
    @room4 = Room.new(params[:room4])
    @living_room = Room.new(params[:living_room])

    respond_to do |format|
      
      @room1.listing = @room2.listing = @room3.listing = @room4.listing = @living_room.listing = @listing
      
      Listing.transaction do
      
        begin
          @listing.save!
          @room1.save!
          @room2.save!
          @room3.save!
          @room4.save!
          
        
        
        rescue ActiveRecord::RecordInvalid => e
          format.html { render :action => "new" }
          format.xml  { render :xml => @listing.errors, :status => :unprocessable_entity }
        end
      end #Listing.transaction
      
    end
  
  end

  # PUT /listings/1
  # PUT /listings/1.xml
  def update
    @listing = Listing.find(params[:id])

    respond_to do |format|
      if @listing.update_attributes(params[:listing])
        flash[:notice] = 'Listing was successfully updated.'
        format.html { redirect_to(@listing) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @listing.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /listings/1
  # DELETE /listings/1.xml
  def destroy
    @listing = Listing.find(params[:id])
    @listing.destroy

    respond_to do |format|
      format.html { redirect_to(listings_url) }
      format.xml  { head :ok }
    end
  end
end
