# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
  

  class ActionView::Helpers::FormBuilder
    def collection_radio(method, collection)
      output = ''
      collection.each {|thing| output += radio_button(method, thing.id) + thing.name + '&nbsp;'}
      output
    end
    
    def yes_no_radio(method)
      #form_builder.select(method, { 'No' => 0, 'Yes' => 1}, {:include_blank => 'Select'})
      collection_radio method, [AttrValue.new(:id=>1, :name=>'y'), AttrValue.new(:id=>0, :name=>'n')]
    end
    
  end

end

