class ACType < AttrValue
end
