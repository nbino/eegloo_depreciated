class AptType < ActiveRecord::Base
  
  def livingroom?
    return !name.include?('studio')
  end
    
end
