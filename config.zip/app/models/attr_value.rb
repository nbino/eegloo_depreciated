class AttrValue < ActiveRecord::Base
end
