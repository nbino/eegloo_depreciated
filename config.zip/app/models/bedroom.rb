class Bedroom < Room
  belongs_to :listing

end
