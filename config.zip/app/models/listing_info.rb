class ListingInfo < ActiveRecord::Base
  has_many :bedrooms
  has_one :livingroom
  belongs_to :listing
  #~ belongs_to :floor_type
  #~ belongs_to :ac_type
  #~ belongs_to :quality_choice
  #~ belongs_to :light_level
  #~ belongs_to :noise_level
  #~ belongs_to :window_direction
  
  def livingroom_info=(livingroom_info)
    build_livingroom livingroom_info
  end
  
  def bedrooms_info=(bedrooms_info)
    bedrooms.build bedrooms_info
  end
  
end
