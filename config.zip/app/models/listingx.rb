class Listingx < ActiveRecord::Base
end
