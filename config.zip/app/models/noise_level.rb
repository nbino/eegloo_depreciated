class NoiseLevel < AttrValue
end
