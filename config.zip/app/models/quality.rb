class Quality < AttrValue
end
