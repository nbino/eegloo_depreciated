class RentRange < ActiveRecord::Base
end
