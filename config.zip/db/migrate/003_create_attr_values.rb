class CreateAttrValues < ActiveRecord::Migration
  def self.up
    create_table :attr_values do |t|
      t.string :name
      t.string :type
      
      t.timestamps
    end
  
  
    ['Quiet', 'Some noise', 'Loud'].each {|name| NoiseLevel.create :name => name}
    
    ['Bright', 'Dim', 'Dark'].each {|name| LightLevel.create :name => name}
    
    ['Garden', 'Street', 'Air Shaft'].each {|name| WindowDirection.create :name => name}
    
    ['Poor', 'Average', 'Excellent'].each {|name| Quality.create :name => name}
    
    ['Carpet', 'Hardwood', 'Linoleum'].each {|name| FloorType.create :name => name}
    
    ['Central', 'Window', 'Wall', 'None'].each {|name| ACType.create :name => name}
    
    [
    'Battery Park', 
    'Chelsea', 
    'Columbus Circle', 
    'East Village', 
    'Financial District', 
    'Flatiron', 
    'Gramercy/Flatiron', 
    'Greenwich Village',
    'Harlem',
    'Hell\'s Kitchen',
    'Lincoln Center',
    'Lower East Side',
    'Meatpacking District',
    'Midtown East',
    'Midtown West',
    'Murray Hill',
    'NoHo',
    'NoLita',
    'Rockefeller Center...',
    'SoHo',
    'Theater District',
    'Times Square',
    'TriBeCa - Downtown',
    'Union Square',
    'Upper East Side',
    'Upper West Side',
    'West Village'
    ].each {|name| Nhood.create :name => name}

  end

  
  def self.down
    drop_table :attr_values
  end
end
