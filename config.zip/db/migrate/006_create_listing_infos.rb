class CreateListingInfos < ActiveRecord::Migration
  def self.up
    create_table :listing_infos do |t|
      t.integer :listing_id,
        :elevator,
        :rent_stabilized,
        :rent_controlled,
        :sq_footage,
        :ceiling_height,
        :convertable,
        :separate_kitchen,
        :no_of_bathrooms,
        :multi_level,
        :penthouse,
        :private_entrance,
        :balcony,
        :patio,
        :back_yard,
        :gym,
        :laundry,
        :roof_access,
        :floor_type_id,
        :heat_q_id,
        :ac_type_id,
        :street_noise_level_id,
        :nbors_noise_level_id,
        :maintenance_q_id,
        :appliance_q_id,
        :bathroom_q_id,
        :roaches,
        :rodents,
        :ants,
        :cellphone_q_id,
        :broadband,
      
      t.string :landlord_phone_number, :broker_phone_number, :comment
      
      t.boolean :broker_only
      
      t.timestamps
    end
  end

  def self.down
    drop_table :listing_infos
  end
end
