class CreateAptTypes < ActiveRecord::Migration
  def self.up
    create_table :apt_types do |t|
      t.string :name
      t.integer :bedrooms
      t.timestamps
    end
    
    [
    {:name=>'studio', :bedrooms=>1},
    {:name=>'alcove studio', :bedrooms=>1},
    {:name=>'jr. 1 bedroom', :bedrooms=>1},
    {:name=>'1 bedroom', :bedrooms=>1},
    {:name=>'jr. 2 bedroom', :bedrooms=>2},
    {:name=>'2 bedroom', :bedrooms=>2},
    {:name=>'jr. 3 bedroom', :bedrooms=>3},
    {:name=>'3 bedroom', :bedrooms=>3},
    {:name=>'4 bedroom', :bedrooms=>4}
    ].each {|vals| AptType.create(vals)}
    
  end

  def self.down
    drop_table :apt_types
  end
end
