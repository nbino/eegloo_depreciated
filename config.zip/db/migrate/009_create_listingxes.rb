class CreateListingxes < ActiveRecord::Migration
  def self.up
    create_table :listingxes do |t|
      t.integer :listing_id, :null => false
      
      t.integer :listing_id, :apt_type_id, :n_hood_id, :rent_range_id
        :rent_range_lbound,
        :rent_range_ubound,
        :sq_footage,
        :ceiling_height,
        :no_of_bathrooms,
        :floor_type_id,
        :heat_q_id,
        :ac_type_id,
        :street_noise_level_id,
        :nbors_noise_level_id,
        :maintenance_q_id,
        :appliance_q_id,
        :bathroom_q_id,
        :cellphone_q_id,
        
      t.boolean 
        :elevator, 
        :rent_stabilized, 
        :rent_controlled, 
        :convertable, 
        :separate_kitchen,
        :multi_level,
        :penthouse,
        :private_entrance,
        :balcony,
        :patio,
        :back_yard,
        :gym,
        :laundry,
        :roof_access,
        :roaches,
        :rodents,
        :ants,
        :broadband
      
      t.string :address, :cross_street, :avail_date, :landlord_phone_number, :broker_phone_number, :comment
      
      # ids to names
      
      t.string
        :apt_type,
        :nhood,
        :rent_range, 
        :floor_type,
        :heat_q,
        :ac_type,
        :street_noise_level,
        :nbors_noise_level,
        :maintenance_q,
        :appliance_q,
        :bathroom_q,
        :cellphone_q
      
      
      t.boolean :broker_only
      
      t.timestamps
    end
  end

  def self.down
    drop_table :listingxes
  end
end
