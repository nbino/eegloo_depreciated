# This file is auto-generated from the current state of the database. Instead of editing this file, 
# please use the migrations feature of ActiveRecord to incrementally modify your database, and
# then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your database schema. If you need
# to create the application database on another system, you should be using db:schema:load, not running
# all the migrations from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 8) do

  create_table "apt_types", :force => true do |t|
    t.string   "name"
    t.integer  "bedrooms"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "attr_values", :force => true do |t|
    t.string   "name"
    t.string   "type"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "listing_infos", :force => true do |t|
    t.integer  "listing_id"
    t.integer  "elevator"
    t.integer  "rent_stabilized"
    t.integer  "rent_controlled"
    t.string   "landlord_phone_number"
    t.string   "broker_phone_number"
    t.boolean  "broker_only"
    t.integer  "sq_footage"
    t.integer  "ceiling_height"
    t.integer  "convertable"
    t.integer  "separate_kitchen"
    t.integer  "no_of_bathrooms"
    t.integer  "multi_level"
    t.integer  "penthouse"
    t.integer  "private_entrance"
    t.integer  "balcony"
    t.integer  "patio"
    t.integer  "back_yard"
    t.integer  "gym"
    t.integer  "laundry"
    t.integer  "roof_access"
    t.integer  "floor_type_id"
    t.integer  "heat_q_id"
    t.integer  "ac_type_id"
    t.integer  "street_noise_level_id"
    t.integer  "nbors_noise_level_id"
    t.integer  "maintenance_q_id"
    t.integer  "appliance_q_id"
    t.integer  "bathroom_q_id"
    t.integer  "roaches"
    t.integer  "rodents"
    t.integer  "ants"
    t.integer  "cellphone_q_id"
    t.integer  "broadband"
    t.string   "comment"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "listings", :force => true do |t|
    t.integer  "user_id",       :null => false
    t.string   "address"
    t.string   "cross_street"
    t.string   "avail_date"
    t.integer  "apt_type_id"
    t.integer  "n_hood_id"
    t.integer  "rent_range_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "rent_ranges", :force => true do |t|
    t.string   "name"
    t.integer  "lbound"
    t.integer  "ubound"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "rooms", :force => true do |t|
    t.string   "type"
    t.integer  "listing_info_id"
    t.integer  "light_level_id"
    t.integer  "window_direction_id"
    t.integer  "length"
    t.integer  "width"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "users", :force => true do |t|
    t.string   "username",        :default => "",    :null => false
    t.string   "password",        :default => "",    :null => false
    t.string   "email",           :default => "",    :null => false
    t.boolean  "basic_access",    :default => false
    t.boolean  "optional_access", :default => false
    t.boolean  "photo_access",    :default => false
    t.boolean  "video_access",    :default => false
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "visuals", :force => true do |t|
    t.integer  "listing_id"
    t.integer  "parent_id"
    t.integer  "size"
    t.integer  "width"
    t.integer  "height"
    t.string   "content_type"
    t.string   "filename"
    t.string   "thumbnail"
    t.string   "comment"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

end
