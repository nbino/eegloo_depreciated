class AcType < AttrValue
end
