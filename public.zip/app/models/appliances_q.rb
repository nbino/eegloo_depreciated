class AppliancesQ < AttrValue
  
end
