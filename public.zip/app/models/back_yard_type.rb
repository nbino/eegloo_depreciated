class BackYardType < AttrValue
  
end
