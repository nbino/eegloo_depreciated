class BathroomQ < AttrValue
  
end
