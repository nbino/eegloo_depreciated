class CellphoneQ < AttrValue
  
end
