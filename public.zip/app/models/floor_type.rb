class FloorType < AttrValue
end
