class HeatQ < AttrValue
end
