class LightLevel < AttrValue
end
