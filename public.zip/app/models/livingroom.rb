class Livingroom < Room
  belongs_to :listing

end
