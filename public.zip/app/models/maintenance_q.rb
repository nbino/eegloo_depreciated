class MaintenanceQ < AttrValue
  
end
