class NborsNoiseLevel < AttrValue
end
