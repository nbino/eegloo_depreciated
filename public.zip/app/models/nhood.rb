class Nhood < AttrValue
end
