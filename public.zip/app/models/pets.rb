class Pets < AttrValue
end
