class Photo < Visual
  
  def blank_image
    'blank_image.gif'
  end
  
  #validates_presence_of :comment
end
