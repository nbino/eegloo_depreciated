class RoofAccessType < AttrValue
end
