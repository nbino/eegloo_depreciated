class StreetNoiseLevel < AttrValue
end
