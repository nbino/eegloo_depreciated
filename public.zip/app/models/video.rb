class Video < Visual
  
  belongs_to :listing
  
  #validates_presence_of :comment
end
