class WindowDirection < AttrValue
end
